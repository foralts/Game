# Empire Rise — Android project

Empire Rise is an original offline life/wealth simulator built from your supplied HTML prototype. This package contains an Android WebView shell and a self-contained local game page. It does not connect to the internet and does not need network permission. Save data uses WebView local storage on the device.

## Build the APK
1. Install Android Studio (current stable) and the Android SDK Platform 35.
2. Open this `EmpireRiseAndroid` folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the output location, typically `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer the APK to your Android phone and install it. If prompted, allow installation from that source.

## Notes
- This environment did not have Gradle/Android SDK available, so the APK itself was not compiled or device-tested here. The project files are prepared for Android Studio build.
- The game uses a local HTML asset and localStorage. Clearing app storage will erase saved game progress.
- All gameplay branding is “Empire Rise”; it is a genre-inspired original project, not the Ambition game or its assets.
